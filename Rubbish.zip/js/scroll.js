$('a.smoothScroll').smoothScroll({
offset: -80,
scrollTarget: $(this).val()
});