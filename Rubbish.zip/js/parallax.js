<script>
    	$(document).ready(function() {
		//"use strict";
        $('#content').parallax("50%", 0.5, true);   		
        $('#join_skandha').parallax("50%", 0.5, true);
        $('#footer').parallax("50%", 0.5, true);
    	});

    </script>